import 'package:flutter/material.dart';

class ContentPage extends StatelessWidget {
  Map<String, String> names = {
    '01': 'Kamboja',
    '02': 'Tabebuya',
    '03': 'Lidah Mertua',
    '04': 'Marigold',
    '05': 'Sekulen',
    '06': 'Lavender',
    '07': 'Pucuk Merah',
    '08': 'Lili',
    '09': 'Lidah Buaya',
    '10': 'Kemuning'
  };
  Map<String, String> desc = {
    '01': ''' Kemboja, kamboja atau semboja (Plumeria) adalah sekelompok tumbuhan dalam marga Plumeria. Bentuknya berupa pohon kecil dengan daun jarang namun tebal. Bunganya yang harumnya sangat khas, dengan mahkota berwarna putih hingga merah keunguan, biasanya lima helai. Bunga dengan empat atau enam helai mahkota bunga oleh masyarakat tertentu dianggap memiliki kekuatan gaib. Jenis akarnya serabut dan tekstur bunganya tidak terlalu kasar dan tidak terlalu halus.

Tumbuhan ini berasal dari Amerika Tengah. Nama Plumeria diberikan untuk menghormati Charles Plumier (1646-1706), pakar botani asal Prancis. Walaupun berasal dari tempat yang jauh, kemboja sekarang merupakan pohon yang sangat populer di Pulau Bali karena ditanam di hampir setiap pura serta sudut kampung, dan memiliki fungsi penting dalam kebudayaan setempat. Di beberapa tempat di Nusantara, termasuk Malaya, kemboja ditanam di pekuburan sebagai tumbuhan peneduh dan penanda tempat. Kemboja dapat diperbanyak dengan mudah, melalui stek batang.

Plumeria saat ini populer digunakan sebagai tanaman hias outdoor awalnya tanaman ini hanya digunakan sebagai tanaman kuburan.

Bunga kamboja tidak hanya terdiri dari satu jenis saja melainkan bermacam-macam, diantaranya Plumeria Bali-Whirl. Bunga kamboja ini memiliki mahkota yang bertumpuk, sedang cara memperbanyak serta melestarikannya adalah dengan penyetekkan. Ada juga Plumeria Acuminata, bentuk mahkotanya membulat serta bagian ujungnya menggulung. Yang ketiga yakni Plumeria Acutifolia, bau bunganya harum dan berkhasiat untuk obat kencing nanah, bengkak serta bisul. Bunga kamboja jenis ini sering digunakan untuk upacara keagamaan oleh orang Bali.

Selanjutnya adalah Plumeria Cendana, meskipun berbau harum tetapi getahnya mengandung racun yang dapat menimbulkan rasa gatal. Plumeria Kok Putih, bunga kamboja ini sekalipun sudah mekar tetap terlihat agak kuncup. Ada juga Adenium Obesum, biasanya orang-orang menyebutnya dengan bunga kamboja Jepang. Bunga ini bukan berasal dari negeri sakura melainkan dari Benua Afrika, tepatnya Tanzania, Kenya, dan Uganda. Tanaman ini juga terkenal dengan sebutan the rose of desert (mawar padang pasir), hal ini disebabkan karena dia mampu bertahan hidup meskipun tumbuh di padang pasir.
Bunga kamboja mempunyai sejumlah senyawa yang berkhasiat sebagai obat, yakni triterprenoid amirin, lupeol, dan fulvoplumierin. Zat-zat tersebut bersifat antipiretik (menurunkan demam), antiinflarnatif (mengatasi radang), dan analgesik (meredakan rasa sakit). Karena kandungan-kandungan inilah, bunga kamboja berguna untuk mengurangi nyeri haid dan mencegah pingsan akibat udara panas atau terkena sinar matahari (heat stroke).

Selain itu, bunga kamboja juga banyak mempunyai khasiat yang lain, yakni sebagai obat luar maupun dalam. Sebagai obat luar, getah kamboja dapat digunakan untuk, misalnya, mengobati gigi berlubang. Caranya adalah dengan melumaskan getah kamboja pada kapas yang kemudian digunakan untuk menutupi gigi yang berlubang. Namun hal ini harus dilakukan dengan sangat hati-hati agar getah kamboja tersebut jangan sampai mengenai gigi yang sehat. Sebagai obat dalam, bunga kamboja dapat digunakan untuk mengobati orang yang terkena penyakit disentri. Caranya adalah dengan memasukkan 12-24 gram bunga kamboja kering ke dalam wadah berisi air 400cc, lalu merebusnya dan menyisakan airnya sampai 200 cc  ''',

    
    
    '02': ''' Tabebuya (Handroanthus chrysotrichus), Tabebuya kuning atau Pohon terompet emas adalah sejenis tanaman yang berasal dari negara Brasil dan termasuk jenis pohon besar. Seringkali tanaman ini dikira sebagai tanaman Sakura oleh kebanyakan orang, karena bila berbunga bentuknya mirip seperti bunga sakura. Namun kedua tanaman ini sebenarnya tidak berkerabat. Pohon tabebuya memiliki kelebihan di antaranya daunnya tidak mudah rontok, disaat musim berbunga maka bunganya terlihat sangat indah dan lebat, akarnya tidak merusak rumah atau tembok walau berbatang keras.

Tanaman Tabebuya memiliki bunga yang berbeda-beda warna. Ada warna kuning dan berbentuk terompet, ada juga yang berwarna pink, ungu, bahkan merah tua. banyak sekali varian tabebuya dari berbagai negara dalam genus handroanthus dan tabebuia dengan warna bunganya yang beraneka macam, tetapi varian yang sering dijumpai di Indonesia adalah yang bunganya berwarna kuning dengan panjang 3-11 cm, berbentuk terompet dan bergerombol.

Setiap spesies pohon tabebuya memiliki warna yang berbeda-beda, saat ini warna yang banyak dikenal adalah putih, merah muda, kuning, kuning jingga, magenta, plum, dan ada yang merah. Terdapat motif garis warna ungu di dalam bunganya. Tabebuya pada musim berbunganya mampu menghasilkan jumlah bunga yang sangat banyak dan tidak putus sejak awal musim kemarau hingga menjelang musim hujan. Bahkan sekarang ini musim pembungaan tanaman ini dapat diatur melalui manipulasi pola pemupukan.

Habitat asli Tabebuya di Brasil berada di daerah dengan iklim kering, sehingga tanaman ini memiliki ketahanan hidup yang tinggi dalam cuaca kering. Hal ini sangat sesuai karena tanaman penghijauan umumnya dihadapkan pada kurangnya penyiraman disaat musim kemarau. Pohon ini adalah pohon hias populer yang dapat tumbuh di berbagai jenis tanah di daerah subtropis dan tropis. Tabebuya adalah pohon dengan pemeliharaan rendah, dimana pemangkasan dibutuhkan hanya untuk menghilangkan tangkai yang mati atau rusak. Jarang ada hama atau penyakit yang mengganggu tanaman ini.

Ada dua jenis pohon tabebuya yang populer sebagai tanaman hias pekarangan: Tabebuya kuning (Handroanthus chrysotrichus) yang pohonnya besar mencapai tinggi 8 m, dan Tabebuya merah muda (Handroanthus impetiginosus atau Handroanthus heptaphyllus) 
Namun demikian, tanaman yang juga dikenal dengan nama tabebuia rosea ini tak semata menyedapkan pandangan. Bersama dengan keindahan yang ditawarkan, bunga tabebuya juga memiliki sederet manfaat. Dari sekian banyak, berikut beberapa di antaranya seperti dikutip dari berbagai sumber :
Bisa melawan malaria

Dengan kandungan berupa naphthoquinone, bunga tabebuya yang sudah diproses menjadi obat herbal ternyata ampuh melawan penyakit malaria. Di samping itu, dengan dosis yang tepat, bunga tabebuya juga bisa memperkuat sistem imun untuk mencegah infeksi.

Membuat udara di sekitar lebih bersih

Bunga tabebuya yang bermekaran di bulan November ini memiliki struktur ranting rindang, serta pohon tidak terlalu tinggi. Pohon tersebut berfungsi untuk penyerapan karbon, serta polusi kendaraan. Jadi, udara sekitar bisa lebih bersih.

Sebagai tanaman hias

Dengan bentuknya yang tak sebegitu besar dan tinggi, pohon bunga tabebuya disebut cocok dijadikan tanaman hias di halaman rumah Anda. Warna bunganya yang bermunculan ketika mekar jadi bonus lain.

Penyembuh luka

Daun dari pohon bunga tabebuya sering kali dimanfaatkan untuk mengobati luka, bahkan menurunkan panas. Merupakan sumber tanaman herbal, pohon ini juga dimanfaatkan sebagai penambah sel darah secara alami bagi pasien pengidap anemia.

Mengobati flu

Akar pohon bunga tabebuya cenderung kering dan di beberapa negara dimanfaatkan sebagai bahan pembuat teh yang disebut tahibo. Walau rasanya kurang menyenangkan, namun minumn ini bisa mengobati flu yang sering menyerang ketika cuaca lebih dingin.

Dimanfaatkan untuk pupuk

Bunga dari pohon tabebuya dapat dijadikan sebagai pupuk untuk menyuburkan tanaman. Caranya cukup mudah, yakni dengan mengumpulkan bunga dari pohon tabebuya yang telah berjatuhan, kemudian diamkan selama beberapa hari. Setelah mengalami pembusukan, maka bunga tersebut bisa dijadikan pupuk.

Terlepas dari semua manfaat yang telah disebutkan di atas, penggunaan pohon bunga tabebuya sebagai pengobatan herbal bisa juga berbahaya. Pasal, komponen aktif di dalam tanaman tersebut juga mengandung racun yang bisa mematikan jika diolah dengan keliru.  ''',
    
    
    '03': ''' Sansevieria atau lidah mertua adalah marga tanaman hias yang cukup populer sebagai penghias bagian dalam rumah karena tanaman ini dapat tumbuh dalam kondisi yang sedikit air dan cahaya matahari. Sansevieria memiliki daun keras, sukulen, tegak, dengan ujung meruncing.

Sanseviera dikenal dengan sebutan tanaman lidah mertua karena bentuknya yang tajam. Sanseviera tak hanya sebagai tanaman hias, tapi juga memiliki manfaat untuk menyuburkan rambut, mengobati diabetes, wasir, hingga kanker ganas. Sementara seratnya digunakan sebagai bahan pakaian. Di Jepang, Sanseviera digunakan untuk menghilangkan bau perabotan rumah di ruangan.

Dibanding tumbuhan lain, Sanseviera memiliki keistimewaan menyerap bahan beracun, seperti karbondioksida, benzene, formaldehyde, dan trichloroethylene.

Sansevieria dibagi menjadi dua jenis, yaitu jenis yang tumbuh memanjang ke atas dengan ukuran 50–75 cm dan jenis berdaun pendek melingkar dalam bentuk roset dengan panjang 8 cm dan lebar 3–6 cm. Kelompok panjang memiliki daun meruncing seperti mata pedang, dan karena ini ada yang menyebut Sansevieria sebagai tanaman pedang-pedangan.

Tumbuhan ini berdaun tebal dan memiliki kandungan air sukulen, sehingga tahan kekeringan. Namun dalam kondisi lembap atau basah, sansiviera bisa tumbuh subur.

Warna daun Sansevieria beragam, mulai hijau tua, hijau muda, hijau abu-abu, perak, dan warna kombinasi putih kuning atau hijau kuning. Motif alur atau garis-garis yang terdapat pada helai daun juga bervariasi, ada yang mengikuti arah serat daun, tidak beraturan, dan ada juga yang zig-zag.

Keistimewaan lidah mertua adalah memiliki daya adaptasi yang tinggi terhadap lingkungan. Penelitian NASA bekerja sama dengan ALCA telah menemukan bukti-bukti bahwa tanaman ini secara alami mampu mengurangi polusi tersebut.

Ditinjau berdasarkan jenisnya sansevieria ada dua jenis yakni yang pertama yaitu sansevieria keturunan asli/spesies sedangkan yang kedua adalah jenis hasil persilangan/hibridasi yang bisa disebut dengan jenis sansevieria hibrid.

Dari bentuk hibrid inilah sansevieria akan tercipta dengan karakter dan fisik yang berbeda dari induknya atau yang sering disebut dengan spesies hibrid atau sansevieria hibrid. Mutasi sansevieria juga dapat terjadi dari perbanyakan melalui stek daun. ''',
   
   
    '04': ''' Marigold atau bunga yang terkenal dengan nama bunga gemitir atau gumitir (khas Pulau Bali), warna kuning cerah yang banyak digunakan sebagai tanaman hias, terutama dalam acara pernikahan. Keindahannya yang mempesona ternyata juga dilengkapi dengan berbagai manfaat kesehatan. Bisa dikonsumsi atau diolah dengan cara lain agar memperoleh manfaatnya, tergantung kebutuhan saja.

Marigold berasal dari genus Tagetes, nama latinnya berbeda tergantung speciesnya, dua yang paling terkenal adalah Tagetes erecta dan Tagetes patula. Soal asal, bunga ini memiliki dua tempat. Ada yang mengatakan berasal dari Meksiko dan ada yang mengatakan berasal dari Amerika Tengah. Di Meksiko, tanaman ini ditemukan tumbuh di alam liar di berbagai negara bagian seperti di Chiapas, San Luis Potosí, Meksiko, Tlaxcala, Sinaloa, Puebla, dan Veracruz.

Bunga ini memiliki ciri berwarna kuning atau orange dengan bunganya yang gemuk, sedikit membulat, memiliki kelopak-kelopak yang saling bertumpukan, ada juga lho yang bunganya berwarna putih. Daun-daun dan batangnya tumbuh membentuk semak dengan ketinggian mampu mencapai 90 centi meter. Di toko kami ini, kami menjual biji tanaman marigold dan tanaman hidup marigold yang sudah jadi

    Di India, bunga marigold dianggap sebagai bunga paling sakral diikuti dengan dijadikannya bunga ini sebagai bunga yang akan dikalungkan pada leher patung dewa di sana. Tak hanya disakralkan dan memiliki keindahan, bunga marigold memiliki manfaat luar biasa yang didapat dari kendungan zat di dalamnya. Dalam setiap kelopak bunga marigold mengandung kandungan serta manfaat yang kami jelaskan sebagai berikut:

Karotenoid. Yakni sebuah pikmen organik yang terdapat dalam tumbuhan. Pigmen ini berperan sebagai antioksidan. Selain ditemukan pada bunga marigold dan tumbuhan lain, Karatenoid juga ditemukan dalam alga, sejumlah bakteri.

β-karoten. Yakni pigmen berwana merah hingga jingga yang secara alamiah ditemukan dalam tumbuhan. Pigmen ini juga berperan sebagai antioksidan, semacam vitamin A dan C. Secara umum, betakaroten ditemukan dalam wortel, labu, dan ubi, sehingga mereka memiliki warna dari merah hingga jingga.

Trans-lutein. Ini sebenarnya juga merupakan salah satu jenis karotenoid yang memiliki fungsi sangat penting. Ia adalah satu-satunya antioksidan yang berfungsi mencegah terjadinya katarak. Selain juga memiliki fungsi anti penuaan dini (antiaging) karena terpapar radiasi sinar UVB matahari.

Mengeluarkan racun dari dalam tubuh. Jika anda mengalami keracunan, anda dapat mengkonsumsi kelopak bunga Morigold. Caranya: seduh kelopak bunga marigol, seperti anda membuat teh. Ini akan membantu Anda membersihkan racun yang masuk dalam tubuh terutama yang berada dalam hati dan kantung empedu Anda.

Mengobati masalah pencernaan. Ketika anda mengkonsumsi kelopak bungan Marigold sebagai teh, anda juga dapat memperoleh manfaat berupa kesehatan pencernaa. Dapat juga mencegah penyakit tukak lambung, gastritis, bahkan kanker perut.

Melawan radikal bebas. Banyaknya kandungan antioksidan yang terdapat dalam bunga Marigold menjadikan bunga ini sangat efektif digunakan untuk mencegah masuknya radikal bebas. Apalagi bunga ini juga memiliki sifat anti-karsinogenik atau anti kanker.

Mengobati demam dan sakit tenggorokan. Caranya masih sama dengan cara nomor 4 dan 5. Yakni menjadikan bunga ini sebagi teh. Teh bunga marigold membantu melawan demam dan batuk. Sementara jika sakit tenggorokan, anda dapat berkumur dengan air bungan marigold sebanyak 3 kali sehari.

Mengobati masalah menstruasi dan menopause.  Teh bunga Morigold memili kandungan atau sifat emmanogogic, sifat ini diketahui secara efektif mempu menenangkan rahim. Sehingga rasa nyeri akan hilang. Kandungan ini juga mampu meringankan menopause.

Melembabkan kulit. Berbeda dengan cara-cara sebelumnya, untuk mendapatkan manfaat pada kulit, Anda dapat menggunakan minyak yang terbuat dari bunga marigold. Kulit anda akan menjadi lebih sehat dan juga terhindar dari masalah kulit.

Mengurangi peradangan. Manfaat ini juga berasal dari minyak bunga Marigold. Kandungan anti inflamasinya sangat baik mengatasi peradangan dan pembengkakan karena cedera.

Mengusir nyamuk. Marigold merupakan salah satu tanaman anti nyamuk paling efektif. Daripada pusing menumbuhkan lavender di dataran rendah (yang jelas lavender sulit kalau di dataran rendah, bagusnya dataran tinggi cuaca sejuk), mending menanam marigold, lebih mudah dan tanamannya juga efektif melawan nyamuk-nyamuk nakal  ''',
   
   
    '05': ''' Sukulen adalah tanaman yang menyimpan air hanya di batang dan gak punya daun, atau punya daun, tapi ukurannya sangat kecil. Definisi sukulen lebih lanjut, kaktus adalah sukulen, tapi gak semua sukulen adalah kaktus.

Mengutip dari britannica.com, tanaman sukulen ditemukan dalam lebih dari 60 famili tanaman, dengan anggota Aizoaceae, Cactaceae, dan Crassulaceae. Sebagian dibudidayakan sebagai tanaman hias, termasuk aloe, echeveria, kalanchoe, dan lainnya.

Beberapa yang terkenal di antaranya tanaman lidah buaya, kaktus bola emas, sukulen panda, sukulen jade dan masih banyak lagi. 

Tanaman sukulen punya banyak manfaat untuk kesehatan, di antaranya meningkatkan kelembapan rumah, karena tanaman ini melepaskan air. 

Selain itu, sukulen bisa membantu memurnikan udara. Penelitian NASA yang menggunakan tanaman di BioHome menunjukkan bahwa sukulen bisa menghilangkan banyak senyawa organik volatil (VOCs) dari udara.

Juga bisa menambahkan oksigen segar ke lingkungan. Gak seperti kebanyakan tanaman, sukulen gak melepaskan karbon dioksida pada malam hari. Sebaliknya, mereka terus menghasilkan oksigen. 

Sukulen juga bisa meningkatkan toleransi nyeri. Penelitian terapi hortikultura yang dilakukan oleh University of Kansas menemukan bahwa pasien kelihatan membutuhkan lebih sedikit obat penghilang rasa sakit saat kamar di rumah sakit ada tanaman. 

Manfaat selanjutnya yaitu bisa meningkatkan memori. Penelitian psikologi yang dilakukan oleh University of Michigan mengungkapkan, banyak manfaat kognitif untuk berinteraksi dengan alam, misalnya dengan berjalan di taman, menanam tanaman di rumah, atau bahkan cuma melihat foto-foto flora. 

Bahkan, retensi memori terbukti meningkat sebanyak 20 persen setelah subjek menghabiskan satu jam di alam.  ''',
   
   
    '06': ''' Lavender (Lavandula spica) adalah tanaman berbunga tahunan yang masuk dalam suku Lamiaceae. Tumbuhan yang berasal dari kawasan Meditrania kemudian menyebar di Eropa hingga Amerika.
    
    Tanaman ini juga dikenal dengan sebutan lavendel atau lavandula. Istilah lavender itu sendiri merupakan bahasa latin dari kata Lavo atau Lavare yang artinya sarana untuk mencuci atau membersihkan.

Selama ini manfaat bunga lavender telah digunakan di industri kosmetik, makanan, hingga untuk obat nyamuk. Sejumlah negara juga memanfaatkan tanaman ini untuk penyedap masakan.

Tanaman lavender juga lama dikenal sebagai herbal dalam pengobatan tradisional. Sejumlah riset menemukan kandungan tanaman ini yang sangat baik untuk kesehatan, khususnya kandungan kimianya.

Lavender kaya dengan minyak atsiri dengan aroma khas lavender yang berwarna kuning bening. Kandungan kimia dalam minyak atsiri lavender juga terbilang beragam, seperti linalyl acetate, linalool, lavendulyl acetate, lavandulol, dan camphor.

Manfaat Bunga Lavender untuk Kesehatan
Kandungan minyak atsiri lavender yang banyak sangat berguna untuk kehidupan manusia. Di bawah ini berbagai manfaat bunga lavender untuk kesehatan yang sebaiknya Anda tahu.

Mengobati Luka dan Gigitan Serangga
Kandungan kimia dalam minyak lavender sangat ampuh dalam menyembuhkan luka maupun karena gigitan serangga. Tinggal oleskan saja minyak lavender pada kulit yang sakit. Namun minyak herbal ini sebaiknya tidak digunakan untuk bayi.

Ampuh Mengusir Nyamuk
Manfaat bunga lavender untuk mengusir nyamuk sangatlah populer. Banyak penelitian yang membuktikan minyak bunga lavender mampu mengumpulkan reseptor kimia pada antena nyamuk, sehingga tak akan mengganggu tidur kita.

Mengusir Jerawat yang Membandel
Minyak bunga lavender ternyata juga efektif untuk mengatasi jerawat yang banyak dialami remaja. Sifat anti-inflamasi dan antiseptik dalam minyak atsiri lavender mampu membunuh bakteri penyebab jerawat.

Menguatkan Rambut dan Mengatasi Ketombe
Manfaat bunga lavender juga telah digunakan dalam pembuatan shampo. Hal ini karena kandungan kimianya sangat baik dalam melindungi rambut dari kerontokan sekaligus menguatkan akar rambut dan mengusir ketombe.

Mengatasi Stress dan Depresi
Minyak atsiri lavender ternyata bersifat menenangkan. Minyak ini sangat baik untuk pemijatan tubuh dan perawatan tubuh. Tinggal lulurkan saja minyak herbal ini sambil memijit tubuh yang lelah agar segar kembali.

Anda juga bisa memetik beberapa tangkai bunga lavender untuk diletakkan di ruang keluarga atau kamar tidur sebagai aroma terapi. Baunya yang harum sangat menenangkan dan memberikan efek relaksasi.

Menyembuhkan Insomnia
Manfaat bunga lavender yang menenangkan juga sangat berguna untuk mengatasi insomnia. Minum saja teh bunga lavender sebelum tidur yang akan membuat tidur menjadi lebih nyenyak.

Mengatasi Eksim
Senyawa kimia dalam minyak bunga lavender juga ampuh dalam mengatasi eksim. Selain meredakan rasa gatal akibat penyakit kulit ini, herbal ini juga mampu mencegah serangan penyakit eksim.

Manfaat Bunga Lavender untuk Kecantikan
Masih banyak manfaat bunga lavender lainnya khususnya untuk kecantikan. Diantaranya bisa sebagai parfum alami yang wangi dan menyehatkan, sebagai kondisioner rambut, maupun sebagai toner untuk perawatan kulit.

Mengatasi Kembung dan Mual
Senyawa kimia dalam minyak lavender juga ampuh dalam mengatasi rasa mual dan mabuk perjalanan. Kandungan polifenol-nya juga efektif mengusir bakteri yang menyebabkan kembung dan gangguan pencernaan. ''',
   
   
    '07': ''' Tanaman dengan nama latin Syzygium oleana ini memang memiliki bentuk yang khas. 

Warna daunnya merah menyala, dan perlahan berubah menjadi hijau seiring pertambahan usia. 

Daunnya pun dan tumbuh rapat antara yang satu dan lainnya.

Tanaman ini seringkali dijadikan tanaman hias di luar rumah oleh masyarakat Indonesia. 

Wajar saja, pucuk merah memang sangat cocok ditanam di daerah tropis.

Suhu tropis seperti Indonesia merupakan kondisi yang ideal yang membuat tanaman ini tumbuh subur. 

Pucuk merah bisa tumbuh hingga diameter 30 centimeter dan tinggi 7 meter, serta usia tanaman dapat mencapai puluhan tahun.

Inilah salah satu alasan kenapa tak sedikit masyarakat Indonesia yang memanfaatkannya sebagai tanaman pagar. 

Walaupun populer karena keindahannya, di balik keindahannya, pucuk merah juga memiliki berbagai manfaat kesehatan. 

Baik itu kesehatan tubuh maupun kesehatan lingkungan.

Apa saja manfaat kesehatan yang dimiliki oleh tanaman pucuk merah?

Manfaat tanaman pucuk merah untuk kesehatan tubuh:
1. Melindungi tubuh dari radikal bebas
Daun pucuk merah mengandung senyawa polifenol, yang bisa digunakan sebagai antioksidan alami. 

Inilah kenapa pucuk merah dapat mengurangi stres dan melindungi tubuh dari paparan radikal bebas yang berbahaya.

2. Pengobatan alternatif tumor dan kanker
Pucuk merah juga mengandung fenolat, antioksidan flavonoid, dan asam batulinic. 

Ketiga kandungan tersebut bisa menjadi pengobatan alternatif untuk mengatasi tumor dan kanker. 

Namun, klaim ini masih belum terbukti oleh penelitian lebih lanjut.

3. Mencegah penyakit diabetes
Kandungan flavonoid pada batang atas pucuk merah mampu mencegah diabetes dan komplikasinya. 

4. Menurunkan kadar asam urat
Terdapat kandungan yang mirip dengan kandungan daun salam pada pucuk merah. 

Salah satu manfaat yang sama antara daun salam dan pucuk merah adalah manfaat untuk menurunkan kadar asam urat. 

5. Mengatasi stres
Percaya atau tidak, kehadiran tanaman di sekitar rumah memang mampu menurunkan kadar stres. 

Begitu juga dengan pucuk merah yang warnanya sangat cantik, ia memiliki dampak yang baik untuk pengelolaan stres. ''',
   
   
    '08': ''' Bunga lili melambangkan cinta yang abadi, kebahagiaan, kerendahan hati, dan ketulusan. Ternyata selain dipakai sebagai bunga hias, tanaman ini punya manfaat untuk kesehatan, lho! Intip manfaat bunga lili di sini.


Bunga lili mempunyai nama latin Lilium Candidum L yang mengandung sejumlah zat kimia penting.

Seperti, dua glikosida, convallamarin, flavonoid yang mengandung anti oksidan, dan masih banyak lagi.

Tanaman lili memiliki ciri-ciri, bunga berwarna putih cerah, batang berbentuk umbi lapis, tidak bercabang, memiliki tinggi antara 0,5 sampai 1,3 meter.

Keunikannya berada pada daunnya pun memiliki bentuk langset dan bunganya seperti lonceng serta aroma yang khas.

Bagi para pecinta bunga lili, kalian pasti tahu ‘kan terdapat manfaat kesehatan yang ada di dalamnya?

Ini dia beberapa daftar manfaat bunga lili yang baik untuk tubuh.

8 Manfaat Bunga Lili untuk Kesehatan Tubuh dan Kulit
1. Tanaman yang Bisa Merawat Luka Bakar
Pertama, manfaat kesehatan yang bisa disembuhkan oleh bunga lili, yaitu merawat luka bakar akibat terkena api.

Kandungannya mampu memulihkan kondisi kulit, sehingga terlihat mulu lagi.

Biasanya bagian yang digunakan untuk merawat luka bakar adalah akar bunga yang diolah menjadi salep kulit.

2. Penyakit Jantung
Selain itu, bunga lily of the valley di Indonesia bisa diolah menjadi ramuan yang dikenal tonik jantung.

Ramuan ini diklain aman untuk merawat penyakit jantung daripada digitalis atau foxglove.

Nantinya ramuan ini dikombinasikan dengan tanaman hawthorn dan motherwort, sehingga manjur untuk mengobati penyakit katup jantung, lemah jantung, hingga gagal jantung kongesif.

Kandungan flavonoid­nya mampu membantu penyebaran darah dan meningkatkan tingkat tekanan darah.

3. Obat Amandel Alami
Nah, jika kamu ingin mengobati amandel secara alami, bisa menggunakan ramuan dari bunga lili.

Manfaat dari bunga lili untuk amandel terdapat pada bagian umbi bunga.

Efeh farmakologisnya bisa mengobati amandel dengan mudah.

Caranya, keringkan umbi bunga lili, lalu rebus dengan air.

Kemudian, saring dan minum ramuan tersebut.

4. Mengelola Infeksi Saluran Kandung Kemih
Bunga peace lily memiliki sifat diuretik, sehingga bisa meningkatkan sekresi urin lewat kerja ginjal.

Sifat diuretik ini dapat mendetoksifikasi hati dan racun-racun yang ada pada tubuh.

5. Manfaat Bunga Lili Sebagai Obat Mata
Mata yang sensitif bisa juga diobati dengan bunga lili.

Maka dari itu, sangat bagus bila obat tetes mata memiliki kandungan ekstrak bunga lili.

Baik dalam versi herbal maupun tradisional.

Sehingga, penyakit mata bisa cepat kempes atau mengecilkan bengkak sekaligus membuat mata kembali nyaman.

6. Bunga Lili untuk Memperbaiki Kesehatan Mental
Ada sebuah legenda yang menyatakan bahwa manfaat bunga lili yang sudah diolah menjadi minyak bisa memberikan ketenangan bila diolesi pada dahi.

Ekstrak bunga lili bisa mengurangi rasa stres yang sedang dialami penggunanya.

Adapula minyak aromaterapi lili yang berguna untuk mengobati sakit kepala, depresi, dan melankolis.

Aromanya akan memperkuat sel otak dan memperbaiki proses kognitifnya.

7. Manfaat Bunga Lili untuk Proses Regenerasi Kulit
Tahukah kamu bahwa kelopak bunga lili mengandung anti oksidan yang tinggi?

Kelopak bunga lili bisa membantu proses regenerasi kulit lebih cepat, sehingg akulit lebih muda dan segar.

Selain itu, kulit akan terasa lebih lembut juga, lho.

8. Dapat Meredakan Demam
Selain cantik, bunga lily of valley ini bisa meredakan demam seperti halnya parasetamol.

Sebab, bunga ini mengandung anti piretik yang diartikan sebagai penyebab kenaikan suhu tubuh. ''',
   
   
    '09': ''' Lidah buaya (Aloe vera) adalah spesies tumbuhan dengan daun berdaging tebal dari genus Aloe. Tumbuhan ini bersifat menahun, berasal dari Jazirah Arab, dan tanaman liarnya telah menyebar ke kawasan beriklim tropis, semi-tropis, dan kering di berbagai belahan dunia. Tanaman lidah buaya banyak dibudidayakan untuk pertanian, pengobatan, dan tanaman hias, dan dapat juga ditanam di dalam pot.

Lidah buaya banyak ditemukan dalam produk seperti minuman, olesan untuk kulit, kosmetika, atau obat luar untuk luka bakar. Walaupun banyak digunakan secara tradisional maupun komersial, uji klinis terhadap tanaman ini belum membuktikan keefektifan atau keamanan ekstrak lidah buaya untuk pengobatan maupun kecantikan.
Aloe vera adalah tumbuhan tanpa batang atau berbatang pendek, dengan tinggi hingga 60–100 cm dan dapat berkembang biak dengan tunas. Dedaunannya berdaging tebal, berwarna hijau atau hijau keabuan, dan sebagian varietas memiliki bintik putih pada permukaan batangnya. Pinggir daunnya berbentuk serrata (seperti gergaji) dengan gerigi putih kecil. Bunga-bunganya tumbuh pada musim panas di sebuah tangkai setinggi hingga 90 cm. Setiap bunga tersebut berposisi menggantung, dan mahkotanya berbentuk tabung sepanjang 2–3 cm. Seperti spesies-spesies Aloe lainnya, Aloe vera membentuk simbiosis mikoriza arbuskula bersama jamur, sehingga meningkatkan ketersediaan mineral dari tanah.

Daun Aloe vera mengandung senyawa-senyawa fitokimia yang sedang diteliti bioaktivitasnya, seperti senyawa manan terasetilasi, polimanan, antrakuinon C-glikosida, dan senyawa antrakuinon lain seperti emodin dan senyawa-senyawa lektin
Manfaat lidah buaya untuk kesehatan 

Dalam dunia kesehatan, bagian lidah buaya yang banyak dimanfaatkan sebagai obat herbal adalah daunnya. 

Asal tahu saja, di dalam daun lidah buaya terdapat daging dan getah gel yang bersifat antiseptik, antipuritik, anestetik, antijamur, antiinflamasi, dan afrosidiak. 

Berikut manfaat lidah buaya untuk kesehatan tubuh. 

Menyembuhkan luka bakar 

Getah gel lidah buaya bersifat antiseptik dan dingin. Hal inilah yang membuat lidah buaya dipercaya ampuh menyembuhkan luka bakar. 

Selain itu, lidah buaya merangsang untuk pembentukan jaringan sel kulit baru. 

Menyembuhkan Sembelit 

Anda sering menderita sembelit? Alih-alih minum serbuk atau pil pencahar Anda bisa mengonsumsi lidah buaya. 

Mengutip dari situs sajiansedap.grid.id, lidah buaya mengandung zat polisakarida yang bisa mengatasi masalah pencernaan. 

Polisakarida membantu tubuh untuk mencerna makanan dengan lebih sempurna sehingga gizi makanan tersebut bisa terserap maksimal. 

Meredakan Batuk 

Lidah buaya juga jadi obat batuk herbal. Sebab, lidah buaya mampu membuang lendir dan menenangkan tenggorokan. 

Menurunkan tekanan darah tinggi 

Mengutip dari Jurnal berjudul Pengaruh Jus Lidah Buaya Terhadap Penurunan Tekanan Darah Pada Penderita Hipertensi karya Shella Ramadhani, lidah buaya mengandung senyawa aktif flavonoid, ariginiin, dan kalium yang bisa menurunkan tekanan darah tinggi. 

Bahkan senyawa aktif dalam lidah buaya juga bisa untuk mengontrol tekanan darah dalam tubuh. Sebagai obat herbal darah tinggi, lidah buaya bisa dikonsumsi dengan cara diolah menjadi jus. 

Diabetes 

Lidah buaya mampu mengendalikan kadar gula darah dalam tubuh. Dalam sebuah penelitian menunjukkan lidah buaya mampu melindungi dan memperbaiki sel beta di pankreas yang memproduksi insulin.

Meredakan asam lambung 

Getah gel lidah buaya bermanfaat untuk menjaga keseimbangan asam perut bila dikonsumsi dengan jumlah tepat.  ''',
    
'10': ''' Kemuning merupakan tanaman yang memiliki aroma yang harum dan berwarna putih. Kemuning juga memiliki nama Latin yaitu Murraya paniculata. Tanaman ini biasanya dijadikan sebagai tanaman hias di pekarangan rumah.

Selain untuk tanaman hias, kemuning juga dijadikan sebagai bahan untuk jamu dan obat herbal. Tapi sayangnya kemuning merupakan salah satu dari tanaman herbal yang langka. Karena kemuning dapat dijadikan sebagai obat herbal, mari lihat apa saja manfaat yang akan didapat dari kemuning bagi tubuh.

1. Mengobati sakit gigi
Manfaat pertama kemuning bagi kesehatan adalah sebagai obat sakit gigi. Kandungan yang terdapat pada kulit batang kemuning dapat digunakan sebagai obat sakit gigi.

Cara pemakaiannya ada dengan membakar kulit batang kemuning kemudian akan mengeluarkan minyak. Setelah itu teteskan minyaknya pada gigi yang sakit.

2. Menghaluskan kulit
Kemuning juga dapat dijadikan sebagai bahan untuk menghaluskan kulit yang kasar. Ambil daun kemuning segar yang telah dicuci lalu ditumbuk kemudian campurkan dengan air lalu aduk hingga rata. Setelah rata, lulurkan bahan tersebut pada kulit sebelum tidur.

3. Mengatasi rematik
Bagian dari kemuning yang bermanfaat bagi tubuh adalah akarnya. Rematik juga bisa diatasi dengan mengonsumsi akar kemuning. Rebus akar kemuning bersama air kemudian minum air rebusan secara teratur untuk mengatasi rematik.

4. Menyembuhkan infeksi saluran kencing
Infeksi saluran kencing merupakan penyakit yang berbahaya bagi tubuh. Kemuning dapat dijadikan sebagai obat alternatif untuk penyakit infeksi saluran kencing. Caranya dengan merebus daun kemuning segar dengan air kemudian konsumsi air rebusan kemuning secara teratur.

5. Menurunkan kolesterol
Kemuning memiliki kandungan kimia berupa tannin, flavanoid, steroid, dan alkaloid yang sangat berguna untuk menurunkan kadar kolesterol. Mengonsumsi ekstrak daun kemuning secara teratur dapat menurunkan kolesterol dan menjaga kolesterol agar tetap stabil. '''  };

  final String value;
  // konstruktor
  ContentPage({Key key, @required this.value}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Informasi'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.share),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(Icons.file_download),
            onPressed: () {},
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Image.asset(
              'images/${this.value}.jpg',
              fit: BoxFit.fill,
            ),
            Container(
              height: 15.0,
            ),
            Row(
              children: <Widget>[
                Container(
                  width: 15.0,
                ),
                Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(names[this.value],
                          style: TextStyle(
                              fontSize: 25.0, fontWeight: FontWeight.bold)),
                      Text(
                        'Tangerang, Banten',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 10.0,
                        ),
                      ),
                    ]),
              ],
            ),
            Container(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                desc[this.value],
                style: TextStyle(
                  fontSize: 16.0,
                ),
                textAlign: TextAlign.justify,
                softWrap: true,
                overflow: TextOverflow.clip,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
