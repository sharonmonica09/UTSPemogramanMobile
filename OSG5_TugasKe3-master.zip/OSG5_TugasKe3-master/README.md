# Aplikasi Atlit Indonesia ( Tugas ke 3 )
Project ini bertema kan tentang Hari Olahraga nasional yang ditugaskan oleh Eudeka pada program training OSG5.

## Screenshot
<a href="https://ibb.co/C12RYKM"><img src="https://i.ibb.co/K0wTfxL/Whats-App-Image-2019-09-12-at-18-11-53.jpg" alt="Whats-App-Image-2019-09-12-at-18-11-53" border="0"></a>

## Built With
- [Flutter](https://flutter.dev)

## Materi 
- UI
- UX
- gridView
- route
- image
- array with MAP

## Created By
-Ary Budi Warsito

## Online Study Group Eudeka!
Salah satu program dari [**Eudeka!**](https://www.eudeka.id) untuk belajar secara _full online_ via Whatsapp/Telegram dan Google Classroom, dengan para praktisi handal di bidangnya. Selain itu juga kamu dapat berkesempatan untuk memperluas koneksimu dengan peserta lain.

## OSG05 - Flutter Basic
Dengan jangka waktu lebih kurang 2 bulan, peserta diharapkan dapat mengenal dan membuat aplikasi simple Flutter dengan menggunakan data dari internet (API).

## Cara Mendaftar Online Study Group
Untuk pendaftaran kelas selanjutnya, silahkan kunjungi atau hubungi kami di dawah ini.

## Info Lebih Lengkap
Website : [www.eudeka.id](https://www.eudeka.id).  
Twitter: [@EudekaID](https://twitter.com/EudekaID).  
Telegram : [@eudekainfo](https://t.me/eudekainfo).  
Instagram : [@eudeka.id](https://instagram.com/eudeka.id).  
WhatsApp : [0895351577557](https://wa.me/62895351577557).  
Email : [info@eudeka.id](mailto:info@eudeka.id).  

[nama_project]: Peserta
[tentang_project]: Peserta
[screenshot_project]: Peserta
[teknologi_digunakan]: Peserta
[nama_peserta]: Peserta

[kode_tugas]: Eudeka
[jenis_kelas]: Eudeka
[nama_kelas]: Eudeka
[tentang_kelas]: Eudeka
[waktu_kelas]: Eudeka
[tujuan_kelas]: Eudeka
[cara_daftar]: Eudeka
[kode_kelas]: Eudeka

###### tags: `Templates` `Eudeka`
